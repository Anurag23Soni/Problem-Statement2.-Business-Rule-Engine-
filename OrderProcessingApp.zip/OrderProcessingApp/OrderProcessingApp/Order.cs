﻿using static OrderProcessingApp.Common;

namespace OrderProcessingApp
{
    public class Order
    {
        public int Id { get; set; }
        public Customer customer { get; set; }
        public decimal amount { get; set; }
        public ProductType productType { get; set; }
        public Product product { get; set; }
        public Status status { get; set; }
    }
}

