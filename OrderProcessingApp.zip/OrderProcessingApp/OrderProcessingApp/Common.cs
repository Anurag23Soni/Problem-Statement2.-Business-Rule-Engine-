﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace OrderProcessingApp
{
    public class Common
    {
        [JsonConverter(typeof(StringEnumConverter))]
        public enum ProductType
        {
            Physical = 1,
            Digital = 2
        }

        [JsonConverter(typeof(StringEnumConverter))]
        public enum Gender
        {
            Unknown = 0,
            Male = 1,
            Female = 2
        }
        [JsonConverter(typeof(StringEnumConverter))]
        public enum Product
        {
            Book = 1,
            Membership = 2,
            Video = 3,
            UpgradeMembership = 4
        }

        [JsonConverter(typeof(StringEnumConverter))]
        public enum Status
        {
            New=1,
            Processing=2,
            Completed=3,
            Canceled=4
        }
    }
}
