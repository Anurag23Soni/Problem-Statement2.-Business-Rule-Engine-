﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OrderProcessingApp
{
   public interface IRule
    {
        List<Order> CheckOrderRule(List<Order> orders);
    }
}
