﻿using System;
using System.Collections.Generic;

namespace OrderProcessingApp
{
    public class Rule : IRule
    {
        public List<Order> CheckOrderRule(List<Order> orders)
        {
            var orderStatus = new List<Order>();
            try
            {
                foreach (Order order in orders)
                {

                    switch (order.productType)
                    {
                        case Common.ProductType.Physical:
                            orderStatus.Add(ManagePhysicalProduct(order));

                            break;
                        case Common.ProductType.Digital:
                            orderStatus.Add(ManageDigitalProduct(order));
                            break;
                    }
                }

            }
            catch (Exception e)
            {
                var log = $"{e.InnerException} Error Occurred In Application";
                Console.WriteLine(log);
            }
            return orderStatus;
        }

        private Order ManagePhysicalProduct(Order order)
        {
            GenerateCommissionPayment();
            var physicalProductOrder = new Order();
            switch (order.product)
            {
                case Common.Product.Book:
                    physicalProductOrder = CreatePackingSlip(order);
                    CreateDuplicatePackingSlip();
                    break;
            }
            return physicalProductOrder;
        }

        private Order ManageDigitalProduct(Order order)
        {
            var digitalProductOrder = new Order();
            switch (order.product)
            {
                case Common.Product.Membership:
                    digitalProductOrder = ActivateMemberShip(order);
                    break;
                case Common.Product.UpgradeMembership:
                    digitalProductOrder = UpdateMemberShip(order);
                    break;
                case Common.Product.Video:
                    digitalProductOrder = CreatePackingSlip(order);
                    break;
            }
            return digitalProductOrder;
        }

        private Order CreatePackingSlip(Order order)
        {
            try
            {
                if (order.product == Common.Product.Video)
                {
                    //video "Learning to Ski", add free "First Aid" video to the packing slip 
                    order.status = Common.Status.Canceled;
                }
                order.status = Common.Status.Completed;
                Console.WriteLine("Packing Slip Create");
            }
            catch (Exception e)
            {
                var log = $"{e.InnerException} Error Occurred In Application";
                Console.WriteLine(log);
            }
            return order;
        }
        private Common.Status CreateDuplicatePackingSlip()
        {
            try
            {
                Console.WriteLine("Duplicate Packing Slip Create");
            }
            catch (Exception e)
            {
                var log = $"{e.InnerException} Error Occurred In Application";
                Console.WriteLine(log);
            }
            return Common.Status.Completed;
        }
        private Order ActivateMemberShip(Order order)
        {
            try
            {
                var log = $"MemberShip Activate For Customer = {order.customer.FirstName}.";
                Console.WriteLine(log);
                order.status = SendNotification(order);
            }
            catch (Exception e)
            {
                var log = $"{e.InnerException} Error Occurred In Application";
                Console.WriteLine(log);
            }
            return order;
        }
        private Order UpdateMemberShip(Order order)
        {
            try
            {
                var log = $"MemberShip Updated For Customer = {order.customer.FirstName}.";
                Console.WriteLine(log);
                order.status = SendNotification(order);
            }
            catch (Exception e)
            {
                var log = $"{e.InnerException} Error Occurred In Application";
                Console.WriteLine(log);
            }
            return order;
        }
        private Common.Status SendNotification(Order order)
        {
            try
            {
                var log = $"Email Send to Customer = {order.customer.FirstName}.";
                Console.WriteLine(log);
            }
            catch (Exception e)
            {
                var log = $"{e.InnerException} Error Occurred In Application";
                Console.WriteLine(log);
            }    
            return Common.Status.Completed;
        }
        private Common.Status GenerateCommissionPayment()
        {
            try
            {
                Console.WriteLine("Commission Payment Generate For Agent");
            }
            catch (Exception e)
            {
                var log = $"{e.InnerException} Error Occurred In Application";
                Console.WriteLine(log);
            }
            return Common.Status.Completed;
        }
    }
}
