﻿using System;
using System.Collections.Generic;


namespace OrderProcessingApp
{
   static class Program 
    {
        static void Main(string[] args)
        {
            List<Order> orders = new List<Order> 
            {
                   new Order {Id=101,customer=new Customer{CustomerId=1,Email="test1@gmail.com",FirstName="testF1",LastName="testl1",Gender=Common.Gender.Male },amount=2.0m,product=Common.Product.Membership,productType=Common.ProductType.Digital,status=Common.Status.Processing},
                   new Order {Id=702,customer=new Customer{CustomerId=2,Email="test2@gmail.com",FirstName="testF2",LastName="testl2",Gender=Common.Gender.Female },amount=212.10m,product=Common.Product.Book,productType=Common.ProductType.Physical,status=Common.Status.Processing},
                   new Order {Id=123,customer=new Customer{CustomerId=3,Email="test3@gmail.com",FirstName="testF3",LastName="testl3",Gender=Common.Gender.Female },amount=200.0m,product=Common.Product.Video,productType=Common.ProductType.Digital,status=Common.Status.Processing},
                   new Order {Id=89,customer=new Customer{CustomerId=1,Email="test1@gmail.com",FirstName="testF1",LastName="testl1",Gender=Common.Gender.Male },amount=898.59m,product=Common.Product.UpgradeMembership,productType=Common.ProductType.Digital,status=Common.Status.Processing},
            };
            IRule iRule = new Rule();
            iRule.CheckOrderRule(orders);
            Console.Read();
        }
    }
}
