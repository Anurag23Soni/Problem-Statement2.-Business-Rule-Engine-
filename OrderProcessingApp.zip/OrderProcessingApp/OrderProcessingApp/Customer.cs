﻿using static OrderProcessingApp.Common;

namespace OrderProcessingApp
{
    public class Customer
    {
        /// <summary>
        /// The customer Id (required for validations).
        /// </summary>
        public int? CustomerId { get; set; }

        /// <summary>
        /// The first name.
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// The last name.
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// The email.
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// The gender.
        /// </summary>
        public Gender Gender { get; set; }
    }
}
